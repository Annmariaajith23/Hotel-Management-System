document.addEventListener("DOMContentLoaded", function () {

    // ================= CUSTOMER DATE VALIDATION =================

    const checkIn = document.querySelector('input[name="check_in"]');
    const checkOut = document.querySelector('input[name="check_out"]');

    if (checkIn && checkOut) {

        function validateCustomerDates() {

            if (checkIn.value && checkOut.value) {

                if (checkOut.value < checkIn.value) {

                    checkOut.setCustomValidity(
                        "Check-out date cannot be earlier than check-in date"
                    );

                } else {

                    checkOut.setCustomValidity("");

                }
            }
        }

        checkIn.addEventListener("change", validateCustomerDates);
        checkOut.addEventListener("change", validateCustomerDates);

    }


    // ================= RESERVATION DATE VALIDATION =================

    const startDate = document.querySelector('input[name="start_date"]');
    const endDate = document.querySelector('input[name="end_date"]');

    if (startDate && endDate) {

        function validateReservationDates() {

            if (startDate.value && endDate.value) {

                if (endDate.value < startDate.value) {

                    endDate.setCustomValidity(
                        "Reservation end date cannot be earlier than start date"
                    );

                } else {

                    endDate.setCustomValidity("");

                }
            }
        }

        startDate.addEventListener("change", validateReservationDates);
        endDate.addEventListener("change", validateReservationDates);

    }

});