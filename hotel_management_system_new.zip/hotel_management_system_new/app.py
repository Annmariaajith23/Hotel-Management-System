from flask import Flask, render_template, request, redirect, url_for, session
import oracledb

app = Flask(__name__)

app.secret_key = "hotel_management_secret_key"

# Oracle Instant Client - Thick Mode
oracledb.init_oracle_client(
    lib_dir="/Users/deonamartin/Downloads/instantclient_23_26"
)


def get_db_connection():
    return oracledb.connect(
        user="HOTEL_MANAGEMENT_SYSTEM",
        password="admin",
        dsn="localhost:1521/XE"
    )

def is_logged_in():
    return "login_id" in session

# ---------------- DASHBOARD ----------------

@app.route("/")
def dashboard():
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT COUNT(*) FROM Hotel")
    hotel_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM Rooms")
    room_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM Customer")
    customer_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM Reservation")
    reservation_count = cursor.fetchone()[0]

    cursor.close()
    connection.close()

    return render_template(
        "dashboard.html",
        hotel_count=hotel_count,
        room_count=room_count,
        customer_count=customer_count,
        reservation_count=reservation_count
    )


# ---------------- CUSTOMERS ----------------

@app.route("/customers")
def customers():
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT Guest_id,
               Name,
               Phone_number,
               Email,
               Country,
               SSN,
               Room_no,
               Check_in_date,
               Check_out_date
        FROM Customer
        ORDER BY Guest_id
    """)

    customers = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template("customers.html", customers=customers)


# ---------------- ADD CUSTOMER ----------------

@app.route("/customers/add", methods=["POST"])
def add_customer():

    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        cursor.execute("""
            INSERT INTO Customer
            (
                Guest_id,
                Name,
                Phone_number,
                Email,
                Country,
                SSN,
                Room_no,
                Check_in_date,
                Check_out_date
            )
            VALUES
            (
                :1,
                :2,
                :3,
                :4,
                :5,
                :6,
                :7,
                TO_DATE(:8, 'YYYY-MM-DD'),
                TO_DATE(:9, 'YYYY-MM-DD')
            )
        """, (
            request.form["guest_id"],
            request.form["name"],
            request.form["phone"] or None,
            request.form["email"] or None,
            request.form["country"] or None,
            request.form["ssn"] or None,
            request.form["room_no"] or None,
            request.form["check_in"] or None,
            request.form["check_out"] or None
        ))

        connection.commit()

        return redirect(url_for("customers"))

    except oracledb.DatabaseError as e:

        if connection:
            connection.rollback()

        error_message = str(e)

        if "ORA-20001" in error_message:
            error_message = "Check-out date cannot be earlier than check-in date"

        return render_template(
            "customers.html",
            error=error_message
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# ---------------- DELETE CUSTOMER ----------------

@app.route("/customers/delete/<int:guest_id>", methods=["POST"])
def delete_customer(guest_id):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute(
        "DELETE FROM Customer WHERE Guest_id = :1",
        (guest_id,)
    )

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("customers"))

# ---------------- UPDATE CUSTOMER ----------------

# ---------------- UPDATE CUSTOMER ----------------

@app.route("/customers/update/<int:guest_id>", methods=["POST"])
def update_customer(guest_id):

    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        cursor.execute("""
            UPDATE Customer
            SET Name = :1,
                Phone_number = :2,
                Email = :3,
                Country = :4,
                SSN = :5,
                Room_no = :6,
                Check_in_date = TO_DATE(:7, 'YYYY-MM-DD'),
                Check_out_date = TO_DATE(:8, 'YYYY-MM-DD')
            WHERE Guest_id = :9
        """, (
            request.form["name"],
            request.form["phone"] or None,
            request.form["email"] or None,
            request.form["country"] or None,
            request.form["ssn"] or None,
            request.form["room_no"] or None,
            request.form["check_in"] or None,
            request.form["check_out"] or None,
            guest_id
        ))

        connection.commit()

        return redirect(url_for("customers"))

    except oracledb.DatabaseError as e:

        if connection:
            connection.rollback()

        error_message = str(e)

        if "ORA-20001" in error_message:
            error_message = "Check-out date cannot be earlier than check-in date"

        return render_template(
            "customers.html",
            error=error_message
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# ---------------- EDIT CUSTOMER PAGE ----------------

@app.route("/customers/edit/<int:guest_id>")
def edit_customer(guest_id):
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT Guest_id,
               Name,
               Phone_number,
               Email,
               Country,
               SSN,
               Room_no,
               TO_CHAR(Check_in_date, 'YYYY-MM-DD'),
               TO_CHAR(Check_out_date, 'YYYY-MM-DD')
        FROM Customer
        WHERE Guest_id = :1
    """, (guest_id,))

    customer = cursor.fetchone()

    cursor.close()
    connection.close()

    if customer is None:
        return "Customer not found", 404

    return render_template("edit_customer.html", customer=customer)

# ---------------- HOTELS ----------------

@app.route("/hotels")
def hotels():
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT Hotel_id,
               Name,
               Location
        FROM Hotel
        ORDER BY Hotel_id
    """)

    hotels = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template("hotels.html", hotels=hotels)


# ---------------- ADD HOTEL ----------------

@app.route("/hotels/add", methods=["POST"])
def add_hotel():

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO Hotel
        (Hotel_id, Name, Location)
        VALUES
        (:1, :2, :3)
    """, (
        request.form["hotel_id"],
        request.form["name"],
        request.form["location"]
    ))

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("hotels"))


# ---------------- DELETE HOTEL ----------------

@app.route("/hotels/delete/<int:hotel_id>", methods=["POST"])
def delete_hotel(hotel_id):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute(
        "DELETE FROM Hotel WHERE Hotel_id = :1",
        (hotel_id,)
    )

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("hotels"))


# ---------------- EDIT HOTEL PAGE ----------------

@app.route("/hotels/edit/<int:hotel_id>")
def edit_hotel(hotel_id):
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT Hotel_id,
               Name,
               Location
        FROM Hotel
        WHERE Hotel_id = :1
    """, (hotel_id,))

    hotel = cursor.fetchone()

    cursor.close()
    connection.close()

    if hotel is None:
        return "Hotel not found", 404

    return render_template("edit_hotel.html", hotel=hotel)


# ---------------- UPDATE HOTEL ----------------

@app.route("/hotels/update/<int:hotel_id>", methods=["POST"])
def update_hotel(hotel_id):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE Hotel
        SET Name = :1,
            Location = :2
        WHERE Hotel_id = :3
    """, (
        request.form["name"],
        request.form["location"],
        hotel_id
    ))

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("hotels"))

# ---------------- ROOMS ----------------

@app.route("/rooms")
def rooms():
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    # Get rooms along with hotel information
    cursor.execute("""
        SELECT r.Room_no,
               r.Room_category,
               r.Hotel_id,
               h.Name,
               h.Location
        FROM Rooms r
        INNER JOIN Hotel h
        ON r.Hotel_id = h.Hotel_id
        ORDER BY r.Room_no
    """)

    rooms = cursor.fetchall()

    # Get hotels for the dropdown
    cursor.execute("""
        SELECT Hotel_id,
               Name,
               Location
        FROM Hotel
        ORDER BY Hotel_id
    """)

    hotels = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template(
        "rooms.html",
        rooms=rooms,
        hotels=hotels
    )


# ---------------- ADD ROOM ----------------

@app.route("/rooms/add", methods=["POST"])
def add_room():

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO Rooms
        (Room_no, Room_category, Hotel_id)
        VALUES
        (:1, :2, :3)
    """, (
        request.form["room_no"],
        request.form["room_category"],
        request.form["hotel_id"]
    ))

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("rooms"))


# ---------------- DELETE ROOM ----------------

@app.route("/rooms/delete/<int:room_no>", methods=["POST"])
def delete_room(room_no):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute(
        "DELETE FROM Rooms WHERE Room_no = :1",
        (room_no,)
    )

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("rooms"))


# ---------------- EDIT ROOM PAGE ----------------

@app.route("/rooms/edit/<int:room_no>")
def edit_room(room_no):
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT Room_no,
               Room_category,
               Hotel_id
        FROM Rooms
        WHERE Room_no = :1
    """, (room_no,))

    room = cursor.fetchone()

    cursor.execute("""
        SELECT Hotel_id,
               Name,
               Location
        FROM Hotel
        ORDER BY Hotel_id
    """)

    hotels = cursor.fetchall()

    cursor.close()
    connection.close()

    if room is None:
        return "Room not found", 404

    return render_template(
        "edit_room.html",
        room=room,
        hotels=hotels
    )


# ---------------- UPDATE ROOM ----------------

@app.route("/rooms/update/<int:room_no>", methods=["POST"])
def update_room(room_no):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE Rooms
        SET Room_category = :1,
            Hotel_id = :2
        WHERE Room_no = :3
    """, (
        request.form["room_category"],
        request.form["hotel_id"],
        room_no
    ))

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("rooms"))

# ---------------- RESERVATIONS ----------------

@app.route("/reservations")
def reservations():
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    # Get reservations with customer and room information
    cursor.execute("""
        SELECT r.Reservation_id,
               r.Guest_id,
               c.Name,
               r.Room_no,
               rm.Room_category,
               TO_CHAR(r.Start_date, 'YYYY-MM-DD'),
               TO_CHAR(r.End_date, 'YYYY-MM-DD')
        FROM Reservation r
        INNER JOIN Customer c
            ON r.Guest_id = c.Guest_id
        INNER JOIN Rooms rm
            ON r.Room_no = rm.Room_no
        ORDER BY r.Reservation_id
    """)

    reservations = cursor.fetchall()


    # Get customers for dropdown
    cursor.execute("""
        SELECT Guest_id,
               Name
        FROM Customer
        ORDER BY Guest_id
    """)

    customers = cursor.fetchall()


    # Get rooms for dropdown
    cursor.execute("""
        SELECT Room_no,
               Room_category
        FROM Rooms
        ORDER BY Room_no
    """)

    rooms = cursor.fetchall()


    cursor.close()
    connection.close()

    return render_template(
        "reservations.html",
        reservations=reservations,
        customers=customers,
        rooms=rooms
    )


# ---------------- ADD RESERVATION ----------------
@app.route("/reservations/add", methods=["POST"])
def add_reservation():

    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        cursor.execute("""
            INSERT INTO Reservation
            (
                Reservation_id,
                Guest_id,
                Room_no,
                Start_date,
                End_date
            )
            VALUES
            (
                :1,
                :2,
                :3,
                TO_DATE(:4, 'YYYY-MM-DD'),
                TO_DATE(:5, 'YYYY-MM-DD')
            )
        """, (
            request.form["reservation_id"],
            request.form["guest_id"],
            request.form["room_no"],
            request.form["start_date"],
            request.form["end_date"]
        ))

        connection.commit()

        return redirect(url_for("reservations"))

    except oracledb.DatabaseError as e:

        if connection:
            connection.rollback()

        error_message = str(e)

        if "ORA-20002" in error_message:
            error_message = "Reservation end date cannot be earlier than start date"

        return render_template(
            "reservations.html",
            error=error_message
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# ---------------- DELETE RESERVATION ----------------

@app.route("/reservations/delete/<int:reservation_id>",
           methods=["POST"])
def delete_reservation(reservation_id):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        DELETE FROM Reservation
        WHERE Reservation_id = :1
        """,
        (reservation_id,)
    )

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("reservations"))


# ---------------- EDIT RESERVATION PAGE ----------------

@app.route("/reservations/edit/<int:reservation_id>")
def edit_reservation(reservation_id):
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    # Get reservation
    cursor.execute("""
        SELECT Reservation_id,
               Guest_id,
               Room_no,
               TO_CHAR(Start_date, 'YYYY-MM-DD'),
               TO_CHAR(End_date, 'YYYY-MM-DD')
        FROM Reservation
        WHERE Reservation_id = :1
    """, (reservation_id,))

    reservation = cursor.fetchone()


    # Get customers
    cursor.execute("""
        SELECT Guest_id,
               Name
        FROM Customer
        ORDER BY Guest_id
    """)

    customers = cursor.fetchall()


    # Get rooms
    cursor.execute("""
        SELECT Room_no,
               Room_category
        FROM Rooms
        ORDER BY Room_no
    """)

    rooms = cursor.fetchall()


    cursor.close()
    connection.close()

    if reservation is None:
        return "Reservation not found", 404

    return render_template(
        "edit_reservation.html",
        reservation=reservation,
        customers=customers,
        rooms=rooms
    )


# ---------------- UPDATE RESERVATION ----------------

@app.route("/reservations/update/<int:reservation_id>",
           methods=["POST"])
def update_reservation(reservation_id):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE Reservation
        SET Guest_id = :1,
            Room_no = :2,
            Start_date = TO_DATE(:3, 'YYYY-MM-DD'),
            End_date = TO_DATE(:4, 'YYYY-MM-DD')
        WHERE Reservation_id = :5
    """, (
        request.form["guest_id"],
        request.form["room_no"],
        request.form["start_date"],
        request.form["end_date"],
        reservation_id
    ))

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("reservations"))

# ---------------- INVOICES ----------------

@app.route("/invoices")
def invoices():
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    # Get invoices with customer names
    cursor.execute("""
        SELECT i.Invoice_id,
               i.Guest_id,
               c.Name,
               i.Status,
               i.Invoice_description
        FROM Invoice i
        INNER JOIN Customer c
            ON i.Guest_id = c.Guest_id
        ORDER BY i.Invoice_id
    """)

    invoices = cursor.fetchall()


    # Get customers for dropdown
    cursor.execute("""
        SELECT Guest_id,
               Name
        FROM Customer
        ORDER BY Guest_id
    """)

    customers = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template(
        "invoices.html",
        invoices=invoices,
        customers=customers
    )


# ---------------- ADD INVOICE ----------------

@app.route("/invoices/add", methods=["POST"])
def add_invoice():

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO Invoice
        (
            Invoice_id,
            Guest_id,
            Status,
            Invoice_description
        )
        VALUES
        (
            :1,
            :2,
            :3,
            :4
        )
    """, (
        request.form["invoice_id"],
        request.form["guest_id"],
        request.form["status"],
        request.form["description"] or None
    ))

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("invoices"))


# ---------------- DELETE INVOICE ----------------

@app.route("/invoices/delete/<int:invoice_id>",
           methods=["POST"])
def delete_invoice(invoice_id):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        DELETE FROM Invoice
        WHERE Invoice_id = :1
        """,
        (invoice_id,)
    )

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("invoices"))


# ---------------- EDIT INVOICE PAGE ----------------

@app.route("/invoices/edit/<int:invoice_id>")
def edit_invoice(invoice_id):
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT Invoice_id,
               Guest_id,
               Status,
               Invoice_description
        FROM Invoice
        WHERE Invoice_id = :1
    """, (invoice_id,))

    invoice = cursor.fetchone()


    cursor.execute("""
        SELECT Guest_id,
               Name
        FROM Customer
        ORDER BY Guest_id
    """)

    customers = cursor.fetchall()

    cursor.close()
    connection.close()

    if invoice is None:
        return "Invoice not found", 404

    return render_template(
        "edit_invoice.html",
        invoice=invoice,
        customers=customers
    )


# ---------------- UPDATE INVOICE ----------------

@app.route("/invoices/update/<int:invoice_id>",
           methods=["POST"])
def update_invoice(invoice_id):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE Invoice
        SET Guest_id = :1,
            Status = :2,
            Invoice_description = :3
        WHERE Invoice_id = :4
    """, (
        request.form["guest_id"],
        request.form["status"],
        request.form["description"] or None,
        invoice_id
    ))

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("invoices"))

# ---------------- BILLS ----------------

@app.route("/bills")
def bills():
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    # Get bills
    cursor.execute("""
        SELECT Bill_id,
               Invoice_id,
               First_name,
               Last_name,
               Amount,
               TO_CHAR(Bill_date, 'YYYY-MM-DD'),
               Type
        FROM Bill
        ORDER BY Bill_id
    """)

    bills = cursor.fetchall()


    # Get invoices for dropdown
    cursor.execute("""
        SELECT Invoice_id,
               Guest_id
        FROM Invoice
        ORDER BY Invoice_id
    """)

    invoices = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template(
        "bills.html",
        bills=bills,
        invoices=invoices
    )


# ---------------- ADD BILL ----------------

@app.route("/bills/add", methods=["POST"])
def add_bill():

    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        cursor.execute("""
            INSERT INTO Bill
            (
                Bill_id,
                Invoice_id,
                First_name,
                Last_name,
                Amount,
                Bill_date,
                Type
            )
            VALUES
            (
                :1,
                :2,
                :3,
                :4,
                :5,
                TO_DATE(:6, 'YYYY-MM-DD'),
                :7
            )
        """, (
            request.form["bill_id"],
            request.form["invoice_id"],
            request.form["first_name"],
            request.form["last_name"],
            request.form["amount"],
            request.form["bill_date"],
            request.form["type"] or None
        ))

        connection.commit()

        return redirect(url_for("bills"))

    except oracledb.DatabaseError as e:

        if connection:
            connection.rollback()

        error_message = str(e)

        # Show our trigger's custom message
        if "ORA-20005" in error_message:
            error_message = "Bill amount cannot be negative"

        return render_template(
            "bills.html",
            error=error_message
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()
    
# ---------------- DELETE BILL ----------------

@app.route("/bills/delete/<int:bill_id>", methods=["POST"])
def delete_bill(bill_id):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        DELETE FROM Bill
        WHERE Bill_id = :1
        """,
        (bill_id,)
    )

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("bills"))


# ---------------- EDIT BILL PAGE ----------------

@app.route("/bills/edit/<int:bill_id>")
def edit_bill(bill_id):
    if "login_id" not in session:
        return redirect(url_for("login"))
    connection = get_db_connection()
    cursor = connection.cursor()

    # Get bill
    cursor.execute("""
        SELECT Bill_id,
               Invoice_id,
               First_name,
               Last_name,
               Amount,
               TO_CHAR(Bill_date, 'YYYY-MM-DD'),
               Type
        FROM Bill
        WHERE Bill_id = :1
    """, (bill_id,))

    bill = cursor.fetchone()


    # Get invoices for dropdown
    cursor.execute("""
        SELECT Invoice_id,
               Guest_id
        FROM Invoice
        ORDER BY Invoice_id
    """)

    invoices = cursor.fetchall()

    cursor.close()
    connection.close()

    if bill is None:
        return "Bill not found", 404

    return render_template(
        "edit_bill.html",
        bill=bill,
        invoices=invoices
    )


# ---------------- UPDATE BILL ----------------

@app.route("/bills/update/<int:bill_id>", methods=["POST"])
def update_bill(bill_id):

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE Bill
        SET Invoice_id = :1,
            First_name = :2,
            Last_name = :3,
            Amount = :4,
            Bill_date = TO_DATE(:5, 'YYYY-MM-DD'),
            Type = :6
        WHERE Bill_id = :7
    """, (
        request.form["invoice_id"],
        request.form["first_name"],
        request.form["last_name"],
        request.form["amount"],
        request.form["bill_date"],
        request.form["type"] or None,
        bill_id
    ))

    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("bills"))

# =========================
# TODAY PRICE ROUTES
# =========================

@app.route("/today-price")
def today_price():
    if "login_id" not in session:
        return redirect(url_for("login"))
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT tp.Hotel_id,
               h.Name,
               h.Location,
               tp.Price,
               tp.Available_rooms,
               TO_CHAR(tp.Price_Date, 'YYYY-MM-DD')
        FROM Today_Price tp
        JOIN Hotel h ON tp.Hotel_id = h.Hotel_id
        ORDER BY tp.Price_Date DESC
    """)

    prices = cursor.fetchall()

    cursor.execute("""
        SELECT Hotel_id, Name, Location
        FROM Hotel
        ORDER BY Hotel_id
    """)

    hotels = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "today_price.html",
        prices=prices,
        hotels=hotels
    )


# ---------------- ADD TODAY PRICE ----------------

@app.route("/today-price/add", methods=["POST"])
def add_today_price():

    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        cursor.execute("""
            INSERT INTO Today_Price
            (
                Hotel_id,
                Price,
                Available_rooms,
                Price_date
            )
            VALUES
            (
                :1,
                :2,
                :3,
                TO_DATE(:4, 'YYYY-MM-DD')
            )
        """, (
            request.form["hotel_id"],
            request.form["price"],
            request.form["available_rooms"],
            request.form["price_date"]
        ))

        connection.commit()

        return redirect(url_for("today_price"))

    except oracledb.DatabaseError as e:

        if connection:
            connection.rollback()

        error_message = str(e)

        if "ORA-20003" in error_message:
            error_message = "Hotel price cannot be negative"

        elif "ORA-20004" in error_message:
            error_message = "Available rooms count cannot be negative"

        return render_template(
            "today_price.html",
            error=error_message
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()    

@app.route("/today-price/delete/<int:hotel_id>/<price_date>", methods=["POST"])
def delete_today_price(hotel_id, price_date):

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            DELETE FROM Today_Price
            WHERE Hotel_id = :1
            AND Price_Date = TO_DATE(:2, 'YYYY-MM-DD')
        """, (
            hotel_id,
            price_date
        ))

        conn.commit()

    except Exception as e:
        conn.rollback()
        cursor.close()
        conn.close()
        return f"Error deleting price: {e}", 400

    cursor.close()
    conn.close()

    return redirect(url_for("today_price"))


@app.route("/today-price/edit/<int:hotel_id>/<price_date>")
def edit_today_price(hotel_id, price_date):
    if "login_id" not in session:
        return redirect(url_for("login"))
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT Hotel_id,
               Price,
               Available_rooms,
               TO_CHAR(Price_Date, 'YYYY-MM-DD')
        FROM Today_Price
        WHERE Hotel_id = :1
        AND Price_Date = TO_DATE(:2, 'YYYY-MM-DD')
    """, (
        hotel_id,
        price_date
    ))

    price = cursor.fetchone()

    cursor.execute("""
        SELECT Hotel_id, Name, Location
        FROM Hotel
        ORDER BY Hotel_id
    """)

    hotels = cursor.fetchall()

    cursor.close()
    conn.close()

    if price is None:
        return "Price record not found", 404

    return render_template(
        "edit_today_price.html",
        price=price,
        hotels=hotels
    )


# ---------------- UPDATE TODAY PRICE ----------------

@app.route("/today-price/update/<int:hotel_id>/<price_date>", methods=["POST"])
def update_today_price(hotel_id, price_date):

    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        price = request.form["price"]
        available_rooms = request.form["available_rooms"]

        cursor.execute("""
            UPDATE Today_Price
            SET Price = :1,
                Available_rooms = :2
            WHERE Hotel_id = :3
            AND Price_Date = TO_DATE(:4, 'YYYY-MM-DD')
        """, (
            price,
            available_rooms,
            hotel_id,
            price_date
        ))

        connection.commit()

        return redirect(url_for("today_price"))

    except oracledb.DatabaseError as e:

        if connection:
            connection.rollback()

        error_message = str(e)

        if "ORA-20003" in error_message:
            error_message = "Hotel price cannot be negative"

        elif "ORA-20004" in error_message:
            error_message = "Available rooms count cannot be negative"

        return render_template(
            "edit_today_price.html",
            error=error_message
        )

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()

# =========================
# LOGIN ROUTES
# =========================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT Login_id, Guest_id, Username
            FROM Login
            WHERE Username = :1
            AND Password = :2
        """, (
            username,
            password
        ))

        user = cursor.fetchone()

        cursor.close()
        conn.close()

        if user:

            session["login_id"] = user[0]
            session["guest_id"] = user[1]
            session["username"] = user[2]

            return redirect(url_for("dashboard"))

        else:

            return render_template(
                "login.html",
                error="Invalid username or password"
            )

    return render_template("login.html")


@app.route("/logout")
def logout():

    session.clear()

    return redirect(url_for("login"))


# ================= RESERVATION SUMMARY =================

@app.route("/reservation-summary")
def reservation_summary():

    if "login_id" not in session:
        return redirect(url_for("login"))

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            c.Name,
            r.Room_no,
            TO_CHAR(r.Start_date, 'YYYY-MM-DD'),
            TO_CHAR(r.End_date, 'YYYY-MM-DD'),
            h.Name,
            tp.Price

        FROM Reservation r

        INNER JOIN Customer c
            ON r.Guest_id = c.Guest_id

        INNER JOIN Rooms rm
            ON r.Room_no = rm.Room_no

        INNER JOIN Hotel h
            ON rm.Hotel_id = h.Hotel_id

        LEFT JOIN Today_Price tp
            ON h.Hotel_id = tp.Hotel_id
            AND TRUNC(tp.Price_Date) = TRUNC(SYSDATE)

        ORDER BY r.Reservation_id
    """)

    data = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template(
        "reservation_summary.html",
        data=data
    )

# ---------------- RUN APPLICATION ----------------

if __name__ == "__main__":
    app.run(debug=False, use_reloader=False, port=5000)